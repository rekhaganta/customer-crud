package com.cg.cms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
