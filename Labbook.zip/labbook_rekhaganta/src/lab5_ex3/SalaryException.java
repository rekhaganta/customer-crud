package lab5_ex3;

public class SalaryException extends Exception {
public SalaryException(String message) {
		
		super(message);
	}

	
}

