package lab5_exe2;

//public class Exercise2 {
	public class NameNotFoundException extends Exception {
		
		public NameNotFoundException(String message)
		{
			super(message);
		}

	}

