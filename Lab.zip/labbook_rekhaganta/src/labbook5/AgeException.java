package labbook5;

//public class Exercise1 {
	public class AgeException extends Exception {
		 
		 public AgeException(String str) {
		  System.out.println(str);
		 }
	}


